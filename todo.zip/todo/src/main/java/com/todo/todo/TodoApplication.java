package com.todo.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoApplication {

	public static void main(String[] args) {

		SpringApplication.run(TodoApplication.class, args);

		// monolitične veb aplikacije
		// baza podataka + html stranice(thymeleaf)

		// aplikacije kao response daje html kodove


		// rest api
		// baza podataka i za odgovor daje podatke u obliku json


		// backend: rest api instagram (salje podatke u obliku json)


		// klijent: veb aplikacija, mobilna apl ios, android, desktop aplikacija... i svi oni salju zahteve ka rest api



		// /proizvodi - POST

		// /narudzbine

		// /proizvodi/3 - GET

		// /proizvodi/7 - DELETE

		// /proizvodi - POST
		// /proizvodi - GET

		// GET - dobavljanje
		// POST - dodavanje informacije
		// PUT - izmena podataka
		// DELETE - brisanie


		// podaci se salju preko json

		//
		/*
		{
			"ime": "Telefon",
			"cena": 20000,
			"kolicina": 20

		}
		*/

		// DOMACI
		// pročitaj o REST API arhitekturi

		// DOMACI2
		// pročitaj šta je servisni sloj(service) u spring boot



	}

}
